# Todo App 10 — Tugas Praktikum 2

Project Next.js untuk **Arsitektur Next.js & React Server Components**.

## Struktur
- `app/page.tsx` sebagai React Server Component
- `app/loading.tsx` dengan simulasi loading 3 detik
- `app/error.tsx` sebagai error boundary client component
- `app/components/` berisi TodoForm, TodoItem, TodoList
- `app/(auth)/login` dan `register` sebagai route group
- `app/task/[id]` sebagai dynamic route
- `types/todo.ts` dan `lib/todos.ts` untuk data

## Menjalankan
```bash
cd frontend
npm install
npm run dev
```
Buka `http://localhost:3000`.

## GitHub
Setelah membuat repository kosong di GitHub:
```bash
cd frontend
git init
git add .
git commit -m "Tugas Praktikum 2 - Todo App 10"
git branch -M main
git remote add origin URL_REPOSITORY_GITHUB_KAMU
git push -u origin main
```
