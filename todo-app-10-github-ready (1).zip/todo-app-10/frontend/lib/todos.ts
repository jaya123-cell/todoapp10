import { Todo } from "@/types/todo";
export const todos: Todo[] = [
{id:"1",title:"Mempelajari Next.js App Router",description:"Memahami routing berbasis folder dan struktur dasar aplikasi.",completed:true,category:"Learning"},
{id:"2",title:"Membuat komponen Todo List",description:"Memisahkan TodoForm, TodoItem, dan TodoList agar kode lebih modular.",completed:false,category:"Development"},
{id:"3",title:"Menyelesaikan Tugas Praktikum 2",description:"Menerapkan Server Component, loading, error handling, route group, dan dynamic route.",completed:false,category:"Assignment"},
{id:"4",title:"Push project ke GitHub",description:"Menyimpan seluruh source code pada repository GitHub untuk pengumpulan tugas.",completed:false,category:"Submission"}
];
export function getTodoById(id:string){return todos.find((todo)=>todo.id===id)}
