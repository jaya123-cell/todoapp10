import Link from "next/link";
import { getTodoById } from "@/lib/todos";
import TaskDetailCard from "./components/TaskDetailCard";
import TaskNotFound from "./components/TaskNotFound";
export default async function TaskPage({params}:{params:Promise<{id:string}>}){const {id}=await params;const todo=getTodoById(id);if(!todo)return <TaskNotFound/>;return <main className="container detail"><Link className="detail-back" href="/">← Kembali ke Todo List</Link><TaskDetailCard todo={todo}/></main>}
