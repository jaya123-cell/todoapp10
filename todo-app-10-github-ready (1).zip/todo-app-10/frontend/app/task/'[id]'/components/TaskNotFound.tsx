import Link from "next/link";
export default function TaskNotFound(){return <main className="container"><section className="card notfound"><div className="eyebrow">404</div><h1>Task tidak ditemukan</h1><p className="todo-desc">ID task yang kamu buka tidak tersedia.</p><Link href="/" className="btn">Kembali ke Todo List</Link></section></main>}
