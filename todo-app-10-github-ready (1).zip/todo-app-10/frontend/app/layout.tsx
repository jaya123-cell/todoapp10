import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
export const metadata: Metadata = { title: "Todo App 10", description: "Tugas Praktikum 2 Next.js" };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body><header className="topbar"><Link href="/" className="brand">Todo<span>App</span> 10</Link><nav className="nav"><Link href="/">Todo</Link><Link href="/login">Login</Link><Link href="/register">Register</Link></nav></header>{children}</body></html>}
