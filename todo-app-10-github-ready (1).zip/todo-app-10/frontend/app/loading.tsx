export default function Loading(){return <main className="loading"><div><div className="spinner"/><h2>Memuat Todo App...</h2><p>Mohon tunggu beberapa saat.</p></div></main>}
