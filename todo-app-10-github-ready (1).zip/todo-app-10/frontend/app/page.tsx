import TodoForm from "./components/TodoForm";
import TodoItem from "./components/TodoItem";
import TodoList from "./components/TodoList";
import { todos } from "@/lib/todos";
const delay=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
export default async function Home(){await delay(3000);const completed=todos.filter(t=>t.completed).length;return <main className="container"><section className="hero"><div><div className="eyebrow">Praktikum 2 · Next.js</div><h1>Kelola tugas dengan lebih rapi.</h1><p>Todo List modular menggunakan App Router dan React Server Components.</p></div><span className="badge">{completed}/{todos.length} tugas selesai</span></section><div className="grid"><TodoForm/><TodoList todos={todos} Item={TodoItem}/></div></main>}
