import RegisterForm from "./RegisterForm";
export default function RegisterPage(){return <main className="auth-wrap"><RegisterForm/></main>}
