import { Todo } from "@/types/todo";
export default function TodoList({todos,Item}:{todos:Todo[];Item:React.ComponentType<{todo:Todo}>}){if(!todos.length)return <div className="empty">Belum ada tugas.</div>;return <section className="card"><h2>Daftar Tugas</h2>{todos.map(todo=><Item key={todo.id} todo={todo}/>)}</section>}
