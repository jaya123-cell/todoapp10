"use client";
export default function Error({reset}:{error:Error & {digest?:string};reset:()=>void}){return <main className="container"><section className="card errorbox"><h1>Terjadi kesalahan</h1><p>Halaman tidak dapat diproses. Silakan coba kembali.</p><button className="btn" onClick={reset}>Coba lagi</button></section></main>}
